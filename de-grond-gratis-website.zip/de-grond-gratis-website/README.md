# Gratis website voor DE GROND

Een snelle, privacyvriendelijke en volledig statische campagnesite. Geen database, geen abonnement en geen betaalde software nodig.

## Wat werkt

- Responsive website voor mobiel, tablet en desktop
- Navigatie, animaties en toegankelijke accordeons
- Missie, speerpunten en Stadskanaal-sectie
- Interesseformulier dat het eigen e-mailprogramma opent
- Geen trackingcookies of externe lettertypen
- Klaar voor gratis hosting op Cloudflare Pages, GitHub Pages of Vercel

## Eerst aanpassen

1. Open `script.js` en vervang:

   `contact@degrond.example`

   door het officiële e-mailadres.

2. Open `index.html` en vervang bij de schema-informatie:

   `https://voorbeeld.pages.dev`

   door de uiteindelijke website-URL.

3. Pas teksten naar wens aan.

## Lokaal bekijken

Je kunt `index.html` dubbelklikken. Voor een realistischer lokale test:

```bash
python3 -m http.server 8080
```

Open daarna `http://localhost:8080`.

## Gratis publiceren via Cloudflare Pages

1. Maak een gratis Cloudflare-account.
2. Ga naar **Workers & Pages**.
3. Kies **Create application** en daarna **Pages**.
4. Upload de hele map via directe upload, of koppel een GitHub-repository.
5. Er is geen buildcommando nodig. De uitvoermap is de hoofdmap.
6. Je ontvangt een gratis adres zoals `de-grond.pages.dev`.

## Gratis publiceren via GitHub Pages

1. Maak een publieke GitHub-repository.
2. Upload alle bestanden.
3. Open **Settings → Pages**.
4. Kies **Deploy from a branch**, branch `main`, map `/root`.
5. De site verschijnt op een gratis `github.io`-adres.

## Wat niet volledig gratis kan

Een officiële ledenadministratie met accounts, databases en iDEAL-betalingen vraagt uiteindelijk om:

- een betaalprovider met transactiekosten;
- veilige server- en database-infrastructuur;
- e-mailbezorging en back-ups;
- juridische en beveiligingscontrole;
- meestal een eigen domeinnaam.

De publieke site kan €0 kosten. Een professioneel lidmaatschapssysteem niet duurzaam en verantwoord.
